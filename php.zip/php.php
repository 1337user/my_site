<?php
        $usr = "web_master";
        $psw = "HTTP_LoooOOOooogiN_passW0RD";
        $username = $_POST['username'];
        $password = $_POST['password'];
        session_start();
       
        if ($_SERVER['REQUEST_METHOD'] == "POST") {
            if($username == $usr && $password == $psw){
                correct();
                exit();

            } else {
                echo '<div class="d-flex justify-content-center text-center">';
                echo '<div class="msg-alert" style="width:50%">';
                echo '<div class="alert alert-danger" role="alert">';
                echo '<h4 class="alert-heading">Login Failed!</h4>';
                echo '<p>username or password is incorrect</p>';
                echo '<hr>';
                echo '<p class="mb-0">Please enter a valid username and password</p>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
        }
?>